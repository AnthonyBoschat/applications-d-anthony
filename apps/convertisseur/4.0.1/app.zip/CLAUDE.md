# Convertisseur: AI manual

Paths relative to `Convertisseur/`. Identity, data folders, requirements: `app.json`. Rules: `Majord/IA/rules.md`.

## Purpose
Convert files between formats inside Obsidian, offline, no external software: images (HEIC included), PDF, Word, notes, HTML, CSV, Excel, JSON.
Type detected from content (binary signature), extension as fallback. ZIP recognised as Word or Excel from its content. Each file offers only the formats possible for its type.

## Files
| Path | Role |
|---|---|
| `Convertisseur.md` | entry note (one French line). Opening it shows the app view |
| `Système/Scripts/vue.js` | screen (`app.json` `view`, `Majord/IA/affichage.md`), history, Inbox import, writing results, deletions |
| `Système/Scripts/conversions.js` | engine: detection and conversions, no rendering, no writes. Returns `{ relativePath, data }[]`. Ends with `return` |
| `Système/Tests/tests.js` | tests without screen (`Majord/IA/build-app.md` §Tests): detection, targets, data conversions. Samples in `Système/Tests/Fichiers/` |
| `Système/Bibliothèques/` | pdf-lib 1.17.1, pdf.js 3.11.174 (`pdf.min.js`, `pdf.worker.min.js`), mammoth 1.8.0, SheetJS 0.18.5 (`xlsx.min.js`), docx 8.5.0, marked 12.0.2, turndown 7.2.0, turndown-plugin-gfm 1.0.2, docx-preview 0.3.3, JSZip 3.10.1, heic2any 0.0.4 (libheif). Licences: `licences.txt` |

## Data
| Folder | Content | Git |
|---|---|---|
| `Inbox/` | files dropped from outside the app, moved to `Originaux/` at once | ignored |
| `Originaux/` | every added file, always kept | ignored |
| `Convertis/` | results. Multi-file outputs in `<name> - pages/` or `<name> - images/` | ignored |
| `Historique/historique.json` | `{ version: 1, files: [{ id, name, original, detection, size, details, addedAt, conversions: [{ id, targetId, label, outputs[], createdAt, with? }] }] }` | ignored |
No properties. Folders created on first use. Files present in `Originaux/` or `Convertis/` without history are not listed.

## Behaviour
- Model: one original, 0..n conversions. Added files (drop zone, "Ajouter des fichiers", Inbox) are copied or moved to `Originaux/` and recorded at once.
- Rules (`reconcile`, run at render, on vault create, delete, rename under `Convertisseur/`, and before opening):
  - a conversion whose results are all gone disappears;
  - an original deleted before any conversion: its row disappears;
  - an original deleted after a conversion: name struck through, label "Original supprimé", no new conversion, conversions still open;
  - an original with no original and no conversion left: row disappears.
- Row actions: "Vers" target + Convertir (first time) or Reconvertir (adds a conversion). Names open the file (Obsidian for md, pdf, images, Windows default app otherwise). "⋯" (`majord.vue.menu`): Ouvrir l'original, Afficher dans le dossier, Supprimer.
- Conversion row: open name, folder button, trash button → window (`majord.vue.ouvrirFenetre`, class `cv-fenetre`) listing what goes to trash and what stays. Original kept.
- Supprimer (⋯): window listing the original and every result, all to Obsidian trash, record removed.
- Selection (`ux.md` §Selection): checkbox per file and per day (`Case`, mixed state), Shift + click range (order = visible list), Escape clears (`useEscape`). Runtime `context.selection` (Set of file ids), not saved, pruned at render.
- Selection bar replaces the toolbar: master checkbox, count, "Tout sélectionner (N)" (visible files), "Désélectionner", "Assembler en un PDF" (all images, ≥ 2), "Fusionner en un PDF" (all PDF, ≥ 2), "Convertir (N)" (each to its row target), "Supprimer (N)" (window listing originals and results, all to trash).
- Assemble or merge window: page order with up and down buttons (rows slide), PDF name (`Saisie`). One conversion on the first file of the order, `with` = other names.
- Search by file or result name (accents ignored), tabs by category with conversion tooltips, day headers, newest first.
- Runtime state `window.cvContexte`: filter, search, chosen targets, running jobs, errors, status. The screen re-renders with `context.refresh()` (no-op while the view is closed, jobs keep running). History loaded from disk when the view opens and no job runs.
- Output names never overwrite: "nom (2)", "nom (3)".
- Libraries loaded on first need by `loadLibrary(file, global)`: `new Function` with `module`, `exports`, `define`, `require` hidden (UMD as in a browser). Cache `window.cvBibliotheques`, one entry per file (docx and docx-preview share the `docx` global). pdf.js worker from a blob URL.

### Conversions
| Detected type | Targets |
|---|---|
| Image (PNG, JPG, WebP, GIF, BMP, AVIF, HEIC) | PNG, JPG, WebP, PDF, light JPG (1920 px, quality 82 %) |
| SVG | PNG, JPG, PDF (≥ 1600 px wide) |
| PDF | PNG or JPG per page, Word (simplified), Markdown note, extract pages ("1-3, 5"), rotate 90°, compress (pages as images) |
| Word (DOCX) | PDF (print), Markdown note (images in `<name> - images`, `![[…]]`), HTML |
| Note (MD, TXT) | PDF (print), DOCX, HTML, EPUB |
| HTML page | PDF (print), Markdown note (scripts and styles removed) |
| CSV | XLSX, JSON, PDF (table) |
| XLSX | CSV (one file per sheet), JSON (one key per sheet), PDF (one sheet per page) |
| JSON | CSV, XLSX, PDF (table). List of records: one sheet. Object of lists: one sheet per key. Other object: "Informations" sheet (Clé, Valeur, nested keys flattened `a.b`) plus one sheet per list of records |
- Unsupported (row marked, no button): PowerPoint, ZIP, malformed JSON, password PDF. Rejected as unreliable: OCR, audio, video, Word to PDF identical to Word.
- Images to PDF: one A4 page per image, oriented like the image, 18 pt margins, never above 96 dpi.
- CSV output: `;`, decimal comma, UTF-8 with BOM. CSV input separator `,` `;` or tab detected, leading zeros kept.
- Excel dates: from serial number (`XLSX.SSF.parse_date_code`), never `Date` (SheetJS 0.18.5 shifts one minute in Europe/Paris). Output `YYYY-MM-DD` or `YYYY-MM-DD HH:MM`. CSV dates `YYYY-MM-DD` or `DD/MM/YYYY` become real Excel dates.
- JSON to table: sub-objects as `parent.child` columns, simple lists as "a, b, c".
- Notes out: properties removed, internal links replaced by their text, `![[…]]` images embedded (PDF, HTML, EPUB), callouts as titled quotes.
- Print to PDF (`printHtmlToPdf`): HTML written into a hidden `<webview>` (`app://obsidian.md/help.html`), `printToPDF`. The help page's own scripts are stopped before writing and anything they add is removed before printing (else the Obsidian logo appears). Selectable text and links kept. Note and HTML: A4, 18 to 20 mm margins. Table PDFs (CSV, XLSX, JSON, targets with `orientable`): A4 landscape (default) or portrait, chosen in a second select (`context.orientations`), saved in the conversion label. Numbers with a decimal comma, booleans Oui and Non (`frenchCells`), dates keep their format. Header row repeated on every page (`withHeaderRow`), smaller text for wide tables (`tableFontSize`: ≤ 8 columns 8.5 pt down to 5 pt beyond 22).
- Word to PDF: docx-preview layout, per-section page size and margins (named `@page`), page breaks kept. Default headers and footers rebuilt from XML (text, simple formatting, tabs, images, page number and count fields). Limits: Chromium pagination, no distinct first-page header, landscape section without preceding break keeps previous size, floating text boxes, SmartArt, equations may move.
- PDF to Word: lines from text positions, paragraphs rejoined (hyphens removed), 3 heading levels from font size, bold and italic from font name, bullets, tables from aligned columns, images in place, one page break per page. Repeated headers, footers, numbers removed. Lost: text columns, exact layout, colors, merged cells. Scanned PDF has no text.

## Visual
- Design `custom`, mockup validated 2026-10-26 (canvas "Convertisseur — maquette"). `ux.md`: comfortable density, max width 1040 px, grouped list (original row, indented conversion rows).
- Declarative screen (`majord.vue`, API 2.0, engine 0.12): `Entete` (summary "N fichiers · M conversions", action "Ajouter des fichiers"), drop zone band, one card: toolbar or selection bar (`Etape`), `Liste` of day headers and file groups, each group a `Liste` of conversion, job and error rows, footer (status `Texte`, folder links).
- Dropdowns: `Choix` (target, orientation). Search and pages fields: `Saisie`. No native `<select>`.
- Own glass card `.cv-carte` (glass on `::before`) reads `--mj-carte`, `--mj-flou`, `--mj-accent`. Windows and menu from the engine, window class `cv-fenetre`. Destructive buttons `danger`.
- Narrow width (container < 760 px): actions on a second line under the name, time hidden, search full width.
- Motion by the engine: a new file, conversion, job or error row opens, a removed one closes. Progress updated in place, never wiped.
- Styles: `const STYLE` in `vue.js`, every selector under `.cv-app` or `.cv-fenetre`.

## User commands
- "Ajoute la conversion X vers Y": add to `conversions.js` (`TARGETS` and `convert`). New library: file in `Système/Bibliothèques/`, line in `licences.txt`, name in `app.json` `requires.checks` command, this manual.
- "Mets à jour les bibliothèques": download from npm, replace files, test every conversion.

## Guardrails
- Reads and writes only inside `Convertisseur/`.
- Never empty `Originaux/` or the trash without user consent. Never edit `historique.json` by hand while a conversion runs.
- Run `Système/Tests/tests.js` after every change of `conversions.js` (bench action `tests`), add a case per new conversion or fixed bug. Not covered there (needs a screen): print to PDF, image assembly, PDF merge, rendering. For those, test with a fake in-memory `app`: Chromium (Playwright) for rendering and non-print conversions, Electron (`xvfb-run`, simulated `app://`, `webviewTag` on) for print to PDF.
- Sensitive actions (for publication review): `new Function` (libraries, engine), `electron.shell.openPath` and `showItemInFolder`, hidden `<webview>` for printing.

## Changelog
| Version | Date | Change |
|---|---|---|
| 4.0.1 | 2026-11-08 | tests without screen (`Système/Tests/`, 14 cases: detection, targets, CSV, JSON, Excel) |
| 4.0.0 | 2026-11-08 | app view (engine 0.12, no Dataview), declarative screen (`majord.vue`): rows open and close, selection bar and toolbar swap with a fade, windows declarative |
| 3.5.0 | 2026-11-07 | motion and stability (`ux.md`): list rebuilt with `majord.ui.rerender` (changed texts wiped in, rows keyed with `data-mj-cle`: files, conversions, jobs, errors, days, tabs, bars), summary wiped when it changes, page order window too. Plain rebuild on engines before 0.11 |
| 3.4.0 | 2026-11-07 | engine renamed Majord: plugin `majord` (was `jarvis`), `majord` API, shared `mj-` classes. Requires engine 0.9.0 |
| 3.3.1 | 2026-10-27 | sensitive actions declared (`permissions`: ouverture-externe, code-dynamique, commandes), `Système/Bibliothèques` declared as `thirdParty`. Requires engine 0.6.0 |
| 3.3.0 | 2026-10-26 | selection (checkboxes, day, Shift range, Escape), bulk convert, assemble and merge chosen files in a chosen order with a name, bulk delete. Old "assemble all" buttons removed. Shadows and hover effects per `design.md` §Shadows and effects |
| 3.2.0 | 2026-10-26 | engine dropdowns (`majord.ui.select`) and text fields (`mj-saisie`) instead of native controls, non-tabular JSON as key and value table, header row on every printed page, smaller text for wide tables, Oui and Non |
| 3.1.0 | 2026-10-26 | JSON to PDF table, orientation choice (paysage, portrait) for table PDFs, French numbers in printed tables |
| 3.0.2 | 2026-10-26 | shared state kept by the newest root only (`claimRoot`), engine removes older duplicate views |
| 3.0.1 | 2026-10-26 | stop a render replaced by a newer one (no duplicate view) |
| 3.0.0 | 2026-10-26 | originals always kept, persistent history (`Historique/`), one original for several conversions, missing files rules, search, day groups, deletion windows, layout per `ux.md`. Setting "Conserver les originaux" and `réglages.json` removed |
| 2.0.1 | 2026-10-26 | no Obsidian logo in printed PDF, deleted results leave the list, Ouvrir never creates a missing file |
| 2.0.0 | 2026-10-25 | Majord app: `app.json` (replaces `prérequis.json`, `dossiers.json`), background and transparency from the Majord plugin (own panel removed), English manual, Inbox, Convertis, Originaux kept out of Git (`gitIgnore`) |
| 1.4 | 2026-10-25 | exact Excel dates in CSV and JSON, decimal comma, real dates CSV to Excel, flattened JSON to table |
| 1.3 | 2026-10-25 | tab tooltips listing possible conversions |
| 1.2 | 2026-10-25 | print to PDF (Word, note, HTML, tables), PDF to Word, PDF compression, note to EPUB, HEIC, HTML to note, embedded images |
| 1.1 | 2026-10-25 | delete a converted file (trash) |
| 1.0 | 2026-10-25 | creation |
