// Convertisseur: main screen, loaded by the Majord app view (app.json "view", engine 0.12, API 1.8, Majord/IA/affichage.md).
// Every added file is kept in Originaux/. Each original has 0..n conversions (Convertis/). History: Historique/historique.json.
// Reads Inbox/ (imported into Originaux/), Système/Bibliothèques/ (on demand). Writes Originaux/, Convertis/, Historique/.
// Declarative display (majord.vue): Majord animates what changes. Own styles scoped to ".cv-app" and ".cv-fenetre".

const LOCALE        = "fr-FR"
const WATCH_DELAY   = 400

const APP_FOLDER       = "Convertisseur"
const SYSTEM_FOLDER    = APP_FOLDER + "/Système"
const SCRIPT_FOLDER    = SYSTEM_FOLDER + "/Scripts"
const LIBRARY_FOLDER   = SYSTEM_FOLDER + "/Bibliothèques"
const INBOX_FOLDER     = APP_FOLDER + "/Inbox"
const OUTPUT_FOLDER    = APP_FOLDER + "/Convertis"
const ORIGINALS_FOLDER = APP_FOLDER + "/Originaux"
const HISTORY_FOLDER   = APP_FOLDER + "/Historique"
const HISTORY_PATH     = HISTORY_FOLDER + "/historique.json"
const ENGINE_PATH      = SCRIPT_FOLDER + "/conversions.js"
const HISTORY_VERSION  = 1

const FORBIDDEN_CHARACTERS = /[\\/:*?"<>|#^\[\]]/g
const OPENABLE_IN_OBSIDIAN = ["md", "pdf", "png", "jpg", "jpeg", "webp", "gif", "svg", "bmp", "avif"]
const PREVIEW_FORMATS      = ["png", "jpg", "gif", "webp", "avif", "bmp", "svg"]

const KINDS = {
  image:   { label: "Image",          tile: "IMG",  color: "#b9dcff", background: "rgba(124,196,255,.2)", category: "images" },
  svg:     { label: "Image vectorielle", tile: "SVG", color: "#b9dcff", background: "rgba(124,196,255,.2)", category: "images" },
  pdf:     { label: "PDF",            tile: "PDF",  color: "#ffc2bc", background: "rgba(255,138,128,.2)", category: "documents" },
  word:    { label: "Word",           tile: "W",    color: "#c3d0ff", background: "rgba(143,168,255,.22)", category: "documents" },
  note:    { label: "Note",           tile: "M",    color: "#e0ccff", background: "rgba(201,167,255,.2)", category: "documents" },
  html:    { label: "Page HTML",      tile: "</>",  color: "#ffd9a8", background: "rgba(245,162,93,.2)",  category: "documents" },
  csv:     { label: "CSV",            tile: "CSV",  color: "#b6f0cb", background: "rgba(111,220,154,.2)", category: "donnees" },
  xlsx:    { label: "Excel",          tile: "XLS",  color: "#b6f0cb", background: "rgba(111,220,154,.2)", category: "donnees" },
  json:    { label: "JSON",           tile: "{ }",  color: "#b6f0cb", background: "rgba(111,220,154,.2)", category: "donnees" },
  inconnu: { label: "Non pris en charge", tile: "?", color: "#c9ced4", background: "rgba(255,255,255,.1)", category: "autres" }
}

const FILTERS = [
  { id: "tous",      label: "Tous" },
  { id: "images",    label: "Images" },
  { id: "documents", label: "Documents" },
  { id: "donnees",   label: "Données" }
]

const CATEGORY_SOURCES = {
  images: {
    sources: [
      { label: "Image (PNG, JPG, WebP, GIF, BMP, AVIF, HEIC)", detection: { kind: "image", format: "autre" } },
      { label: "Image vectorielle (SVG)",                       detection: { kind: "svg",   format: "svg" } }
    ],
    groups: ["Plusieurs images → un seul PDF"]
  },
  documents: {
    sources: [
      { label: "PDF",            detection: { kind: "pdf",  format: "pdf" } },
      { label: "Word (DOCX)",    detection: { kind: "word", format: "word" } },
      { label: "Note (MD, TXT)", detection: { kind: "note", format: "note" } },
      { label: "Page HTML",      detection: { kind: "html", format: "html" } }
    ],
    groups: ["Plusieurs PDF → un PDF fusionné"]
  },
  donnees: {
    sources: [
      { label: "CSV",          detection: { kind: "csv",  format: "csv" } },
      { label: "Excel (XLSX)", detection: { kind: "xlsx", format: "xlsx" } },
      { label: "JSON",         detection: { kind: "json", format: "json" } }
    ],
    groups: []
  }
}



const STYLE = `
.cv-app { --cv-carte: var(--mj-carte); --cv-flou: var(--mj-flou); --cv-accent: var(--mj-accent); --cv-ligne: rgba(255,255,255,.08); container-type: inline-size; width: 100%; max-width: 1040px; margin: 16px auto 24px; gap: 16px; color: #eef1f4; font-size: 13px; line-height: 1.4; text-shadow: 0 1px 2px rgba(0,0,0,.25); }
.cv-app * { box-sizing: border-box; }
.cv-app .cv-doux { color: #c2c9d1; }
.cv-app .cv-faible { color: #aab3bc; }
.cv-app .cv-depot { display: flex; align-items: center; justify-content: center; gap: 12px; min-height: 56px; padding: 8px 16px; border-radius: 14px; border: 1.5px dashed color-mix(in srgb, var(--cv-accent) 60%, transparent); background: rgba(12,14,20,.35); color: #d6dbe0; cursor: pointer; text-align: center; transition: background-color .18s ease, border-color .18s ease; }
.cv-app .cv-depot:hover, .cv-app.cv-glisse .cv-depot { background: color-mix(in srgb, var(--cv-accent) 14%, rgba(12,14,20,.35)); border-color: var(--cv-accent); }
.cv-app .cv-depot:focus-visible { outline: 2px solid #ffffff; outline-offset: 2px; }
.cv-app .cv-carte { position: relative; isolation: isolate; border-radius: 16px; border: 1px solid rgba(255,255,255,.1); box-shadow: var(--mj-ombre-1); }
.cv-app .cv-carte::before { content: ""; position: absolute; inset: 0; z-index: -1; border-radius: inherit; background: var(--cv-carte); backdrop-filter: blur(var(--cv-flou)) saturate(140%); -webkit-backdrop-filter: blur(var(--cv-flou)) saturate(140%); }
.cv-app .cv-barre { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; padding: 12px 16px; border-bottom: 1px solid var(--cv-ligne); }
.cv-app .cv-espace { flex: 1; }
.cv-app .cv-barre.cv-selection { border-radius: 16px 16px 0 0; min-height: 61px; background: color-mix(in srgb, var(--cv-accent) 10%, transparent); padding-left: 24px; }
.cv-app .cv-selection-compte { font-weight: 600; color: #ffffff; }
.cv-app button.cv-bouton.cv-danger-ligne { border-color: rgba(255,138,128,.6); color: #ffc2bc; }
.cv-app button.cv-bouton.cv-danger-ligne:hover { background: rgba(255,138,128,.14); }
.cv-app .cv-groupe.cv-choisi { background: color-mix(in srgb, var(--cv-accent) 8%, transparent); }
.cv-app .cv-jour { display: flex; align-items: center; gap: 12px; }
.cv-app button.cv-onglet { all: unset; box-sizing: border-box; height: 36px; padding: 0 12px; border-radius: 8px; color: #c2c9d1; font-weight: 600; cursor: pointer; }
.cv-app button.cv-onglet:hover { color: #ffffff; }
.cv-app button.cv-onglet.cv-actif { background: rgba(255,255,255,.11); color: #ffffff; }
.cv-app button.cv-onglet .cv-compte { margin-left: 6px; opacity: .75; font-family: var(--mj-mono); font-size: 12px; }
.cv-app .cv-recherche { width: 240px; }
.cv-app button.cv-bouton { all: unset; box-sizing: border-box; display: inline-flex; align-items: center; justify-content: center; gap: 8px; height: 36px; padding: 0 14px; border-radius: 8px; border: 1px solid rgba(255,255,255,.16); color: #eef1f4; font-weight: 600; cursor: pointer; white-space: nowrap; transition: background-color .18s ease, border-color .18s ease, color .18s ease; }
.cv-app button.cv-bouton:hover { background: rgba(255,255,255,.08); }
.cv-app button.cv-bouton.cv-petit { height: 36px; padding: 0 12px; }
.cv-app button.cv-bouton.cv-principal { background: var(--cv-accent); border-color: var(--cv-accent); color: var(--mj-sur-accent); text-shadow: none; }
.cv-app button.cv-bouton.cv-principal:hover { background: color-mix(in srgb, var(--cv-accent) 88%, #ffffff); }
.cv-app button.cv-bouton.cv-accent { border-color: color-mix(in srgb, var(--cv-accent) 70%, transparent); color: color-mix(in srgb, var(--cv-accent) 45%, #ffffff); }
.cv-app button.cv-bouton:disabled { opacity: .45; cursor: default; }
.cv-app button.cv-icone { all: unset; box-sizing: border-box; flex: none; width: 36px; height: 36px; border-radius: 8px; display: flex; align-items: center; justify-content: center; color: #c2c9d1; cursor: pointer; }
.cv-app button.cv-icone.cv-petite { width: 32px; height: 32px; }
.cv-app button.cv-icone:hover { background: rgba(255,255,255,.08); color: #ffffff; }
.cv-app button.cv-icone.cv-danger:hover { background: rgba(255,138,128,.16); color: #ffc2bc; }
.cv-app button:focus-visible, .cv-app select:focus-visible, .cv-app a:focus-visible { outline: 2px solid #ffffff; outline-offset: 2px; }
.cv-app .cv-jour { padding: 16px 24px 4px; color: #98a1ab; font-size: 11px; font-weight: 600; letter-spacing: .08em; text-transform: uppercase; }
.cv-app .cv-jour + .cv-groupe { border-top: 0; }
.cv-app .cv-groupe { border-top: 1px solid var(--cv-ligne); padding-bottom: 4px; }
.cv-app .cv-jour:not(:first-child) { border-top: 1px solid var(--cv-ligne); }
.cv-app .cv-ligne { display: flex; align-items: center; gap: 16px; min-height: 64px; padding: 8px 16px 8px 24px; }
.cv-app .cv-vignette { flex: none; width: 36px; height: 36px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 10px; font-weight: 700; background-size: cover; background-position: center; }
.cv-app .cv-vignette.cv-absente { background: rgba(255,255,255,.06) !important; color: #8d969f !important; border: 1px dashed rgba(255,255,255,.2); }
.cv-app .cv-fichier { display: flex; flex-direction: column; gap: 2px; flex: 1; min-width: 0; }
.cv-app .cv-titre { display: flex; align-items: center; gap: 8px; min-width: 0; }
.cv-app a.cv-nom { font-size: 15px; font-weight: 500; color: #ffffff; text-decoration: none; cursor: pointer; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
.cv-app a.cv-nom:hover { text-decoration: underline; }
.cv-app .cv-barre-nom { font-size: 15px; font-weight: 500; color: #98a1ab; text-decoration: line-through; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
.cv-app .cv-meta { font-size: 12px; color: #aab3bc; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
.cv-app .cv-etiquette { flex: none; border-radius: 6px; padding: 2px 8px; font-size: 12px; font-weight: 600; white-space: nowrap; }
.cv-app .cv-etiquette.cv-alerte { background: rgba(255,196,107,.16); color: #ffd28f; }
.cv-app .cv-actions { display: flex; align-items: center; gap: 8px; }
.cv-app .cv-cible { display: flex; align-items: center; gap: 8px; color: #c2c9d1; }
.cv-app .cv-actions .mj-deroulant { max-width: 240px; }
.cv-app .cv-pages { width: 160px; }
.cv-app .cv-enfant { display: flex; align-items: center; gap: 12px; min-height: 44px; padding: 0 16px 0 110px; color: #c2c9d1; }
.cv-app .cv-enfant > svg { flex: none; color: #8be8b0; }
.cv-app .cv-enfant.cv-en-cours > svg { color: var(--cv-accent); }
.cv-app .cv-enfant.cv-echec > svg { color: #ff8a80; }
.cv-app .cv-enfant .cv-sortie { flex: 1; min-width: 0; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
.cv-app .cv-enfant a.cv-nom { font-size: 13px; }
.cv-app .cv-heure { width: 96px; text-align: right; font-size: 12px; color: #aab3bc; white-space: nowrap; }
.cv-app .cv-progression { flex: 1; display: flex; flex-direction: column; gap: 6px; min-width: 0; font-size: 12px; }
.cv-app .cv-jauge { height: 4px; border-radius: 2px; background: rgba(255,255,255,.1); overflow: hidden; }
.cv-app .cv-jauge i { display: block; height: 100%; width: 0; background: var(--cv-accent); transition: width .2s ease; }
.cv-app .cv-jauge.cv-indefini i { width: 35%; animation: cv-glisse 1.1s ease-in-out infinite; }
.cv-app .cv-erreur { flex: 1; color: #ffc2bc; font-size: 12px; font-weight: 500; }
.cv-app .cv-vide { display: flex; flex-direction: column; align-items: center; gap: 8px; padding: 48px 24px; text-align: center; }
.cv-app .cv-vide b { font-size: 15px; font-weight: 600; color: #ffffff; }
.cv-app .cv-pied { display: flex; align-items: center; gap: 16px; flex-wrap: wrap; padding: 12px 24px; border-top: 1px solid var(--cv-ligne); font-size: 12px; }
.cv-app button.cv-lien { all: unset; color: color-mix(in srgb, var(--cv-accent) 45%, #ffffff); font-weight: 600; cursor: pointer; }
.cv-app button.cv-lien:hover { color: #ffffff; text-decoration: underline; }
.cv-app .cv-statut { color: #ffffff; font-weight: 500; }
.cv-app .cv-statut:empty { display: none; }
.cv-app .cv-liste, .cv-app .cv-enfants { display: flex; flex-direction: column; }
.cv-fenetre .cv-fenetre-liste { display: flex; flex-direction: column; gap: 4px; max-height: 220px; overflow-y: auto; }
.cv-fenetre .cv-ordre { display: flex; flex-direction: column; gap: 8px; }
.cv-fenetre .cv-ordre-ligne { display: flex; align-items: center; gap: 12px; min-height: 48px; padding: 0 8px 0 12px; border-radius: 10px; background: rgba(255,255,255,.04); border: 1px solid rgba(255,255,255,.08); }
.cv-fenetre .cv-ordre-numero { width: 20px; text-align: right; color: var(--mj-doux); font-weight: 600; }
.cv-fenetre .cv-ordre-nom { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: #ffffff; font-weight: 500; }
.cv-app .cv-enfant > .mj-icone { flex: none; color: #8be8b0; }
.cv-app .cv-enfant.cv-en-cours > .mj-icone { color: var(--cv-accent); }
.cv-app .cv-enfant.cv-echec > .mj-icone { color: #ff8a80; }
.cv-app .cv-depot .mj-icone svg, .cv-app .cv-enfant .mj-icone svg, .cv-app button.cv-icone .mj-icone svg { width: 16px; height: 16px; }
@keyframes cv-glisse { from { transform: translateX(-100%); } to { transform: translateX(300%); } }
@container (max-width: 760px) {
  .cv-app .cv-ligne { flex-wrap: wrap; row-gap: 8px; }
  .cv-app .cv-actions { order: 5; flex: 1 1 100%; flex-wrap: wrap; padding-left: 86px; }
  .cv-app .cv-cible-libelle { display: none; }
  .cv-app .cv-enfant { padding-left: 86px; flex-wrap: wrap; }
  .cv-app .cv-heure { display: none; }
  .cv-app .cv-recherche { flex: 1 1 100%; width: auto; order: 9; }
}
@media (prefers-reduced-motion: reduce) { .cv-app * { transition: none !important; animation: none !important; } }
`


// ---------- Tools ----------

function escapeHtml(text) {
  const value   = String(text ?? "")
  const escaped = value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;")
  return escaped
}




function formatSize(bytes) {
  const KILO = 1024
  if (bytes < KILO) return bytes + " o"
  if (bytes < KILO * KILO) return Math.round(bytes / KILO) + " Ko"
  const megabytes = bytes / KILO / KILO
  return megabytes.toLocaleString("fr-FR", { maximumFractionDigits: 1 }) + " Mo"
}


function splitName(name) {
  const dotIndex  = name.lastIndexOf(".")
  const hasDot    = dotIndex > 0
  const base      = hasDot ? name.slice(0, dotIndex) : name
  const extension = hasDot ? name.slice(dotIndex + 1) : ""
  return { base, extension }
}


function safeName(name) {
  return name.replace(FORBIDDEN_CHARACTERS, "-").trim() || "fichier"
}


async function readJson(path, fallback) {
  const exists = await app.vault.adapter.exists(path)
  if (!exists) return fallback
  try {
    const raw = await app.vault.adapter.read(path)
    return JSON.parse(raw.replace(/^﻿/, ""))
  } catch (error) {
    return fallback
  }
}


async function writeJson(path, data) {
  const content = JSON.stringify(data, null, 2) + "\n"
  await app.vault.adapter.write(path, content)
}


async function ensureFolder(path) {
  const exists = await app.vault.adapter.exists(path)
  if (!exists) await app.vault.adapter.mkdir(path)
}


async function uniquePath(folder, base, extension) {
  let counter   = 1
  let candidate = folder + "/" + base + (extension ? "." + extension : "")
  while (await app.vault.adapter.exists(candidate)) {
    counter++
    candidate = folder + "/" + base + " (" + counter + ")" + (extension ? "." + extension : "")
  }
  return candidate
}


async function chooseBaseName(base, extension) {
  let counter   = 1
  let candidate = base
  const taken   = async name => (await app.vault.adapter.exists(OUTPUT_FOLDER + "/" + name + "." + extension)) || (await app.vault.adapter.exists(OUTPUT_FOLDER + "/" + name + " - pages")) || (await app.vault.adapter.exists(OUTPUT_FOLDER + "/" + name + " - images"))
  while (await taken(candidate)) {
    counter++
    candidate = base + " (" + counter + ")"
  }
  return candidate
}


function getNodeModules() {
  const nodeRequire = window.require
  if (typeof nodeRequire !== "function") return null
  try {
    return { electron: nodeRequire("electron"), path: nodeRequire("path") }
  } catch (error) {
    return null
  }
}


// ---------- Libraries and conversion engine ----------

async function loadLibrary(fileName, globalName) {
  const cache = window.cvBibliotheques ?? {}
  window.cvBibliotheques = cache
  if (cache[fileName]) return cache[fileName]
  const path      = LIBRARY_FOLDER + "/" + fileName
  const exists    = await app.vault.adapter.exists(path)
  if (!exists) throw new Error("Bibliothèque manquante : " + fileName + " (voir Santé du vault).")
  const code      = await app.vault.adapter.read(path)
  const lookup    = "\n;return (typeof " + globalName + " !== 'undefined') ? " + globalName + " : globalThis." + globalName
  const factory   = new Function("module", "exports", "define", "require", code + lookup)
  const library   = factory.call(globalThis, undefined, undefined, undefined, undefined)
  if (!library) throw new Error("Bibliothèque illisible : " + fileName)
  cache[fileName] = library
  return library
}
loadLibrary.folder = LIBRARY_FOLDER


async function loadEngine() {
  const code    = await app.vault.adapter.read(ENGINE_PATH)
  const factory = new Function("app", "loadLibrary", code)
  return factory(app, loadLibrary)
}



// ---------- History (Historique/historique.json) ----------

function newId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7)
}


async function loadHistory() {
  const data  = await readJson(HISTORY_PATH, null)
  const files = data && Array.isArray(data.files) ? data.files : []
  for (const file of files) if (!Array.isArray(file.conversions)) file.conversions = []
  return files
}


async function saveHistory(context) {
  await ensureFolder(HISTORY_FOLDER)
  const files = context.files.map(file => {
    const stored = Object.assign({}, file)
    delete stored.missing
    return stored
  })
  await writeJson(HISTORY_PATH, { version: HISTORY_VERSION, files: files })
}


function findFile(context, id) {
  return context.files.find(file => file.id === id) ?? null
}


function hasJob(context, file) {
  return Boolean(context.jobs[file.id])
}


// Applies the user's rules after any change on disk:
// a conversion without results disappears, an original deleted before any conversion disappears,
// an original deleted after a conversion stays (struck through) while its conversions exist.
async function reconcile(context) {
  let changed = false
  let visible = false
  const kept  = []
  for (const file of context.files) {
    const originalExists = await app.vault.adapter.exists(file.original)
    if (Boolean(file.missing) !== !originalExists) visible = true
    file.missing = !originalExists
    const conversions = []
    for (const conversion of file.conversions) {
      const present = []
      for (const path of conversion.outputs) if (await app.vault.adapter.exists(path)) present.push(path)
      if (present.length !== conversion.outputs.length) changed = true
      conversion.outputs = present
      if (present.length) conversions.push(conversion)
    }
    file.conversions = conversions
    const keep = originalExists || conversions.length > 0 || hasJob(context, file)
    if (keep) kept.push(file)
    else changed = true
  }
  context.files = kept
  if (changed) await saveHistory(context)
  return changed || visible
}


// ---------- Adding files ----------

async function registerOriginal(context, name, bytes, path) {
  const detection = context.engine.detectKind(bytes, name)
  const details   = await context.engine.describe(bytes, detection)
  const file      = {
    id:          newId(),
    name:        name,
    original:    path,
    detection:   detection,
    size:        bytes.byteLength,
    details:     details,
    addedAt:     new Date().toISOString(),
    conversions: []
  }
  context.files.push(file)
  return file
}


async function storeOriginal(name, bytes) {
  await ensureFolder(ORIGINALS_FOLDER)
  const parts  = splitName(name)
  const target = await uniquePath(ORIGINALS_FOLDER, safeName(parts.base), parts.extension)
  await app.vault.adapter.writeBinary(target, bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength))
  return target
}


async function addExternalFiles(context, fileList) {
  const files = Array.from(fileList ?? [])
  for (const item of files) {
    const bytes = new Uint8Array(await item.arrayBuffer())
    const path  = await storeOriginal(item.name, bytes)
    await registerOriginal(context, item.name, bytes, path)
  }
  return files.length
}


// Files dropped in Inbox/ outside the app are moved into Originaux/.
async function importInbox(context) {
  await ensureFolder(INBOX_FOLDER)
  const listing = await app.vault.adapter.list(INBOX_FOLDER)
  const paths   = listing.files.filter(path => !path.split("/").pop().startsWith("."))
  for (const path of paths) {
    const name   = path.split("/").pop()
    const bytes  = new Uint8Array(await app.vault.adapter.readBinary(path))
    await ensureFolder(ORIGINALS_FOLDER)
    const parts  = splitName(name)
    const target = await uniquePath(ORIGINALS_FOLDER, safeName(parts.base), parts.extension)
    const item   = app.vault.getAbstractFileByPath(path)
    if (item) await app.vault.rename(item, target)
    else await app.vault.adapter.rename(path, target)
    await registerOriginal(context, name, bytes, target)
  }
  return paths.length
}


async function addFiles(context, fileList) {
  const count = fileList ? fileList.length : 0
  if (!count) return
  setStatus(context, "Lecture de " + count + (count > 1 ? " fichiers…" : " fichier…"))
  await addExternalFiles(context, fileList)
  await saveHistory(context)
  setStatus(context, "")
  render(context)
}


// ---------- Conversions ----------

function readableError(error) {
  const message = error && error.message ? error.message : String(error)
  return message.length > 160 ? message.slice(0, 160) + "…" : message
}


function chosenTarget(context, file) {
  const chosen = context.targets[file.id]
  const valid  = context.engine.getTargets(file.detection).some(target => target.id === chosen)
  return valid ? chosen : context.engine.getDefaultTarget(file.detection)
}


function canConvert(context, file) {
  return !file.missing && file.detection.kind !== "inconnu" && !hasJob(context, file) && Boolean(chosenTarget(context, file))
}


async function writeOutputs(outputs) {
  const written = []
  for (const output of outputs) {
    const fullPath = OUTPUT_FOLDER + "/" + output.relativePath
    const folder   = fullPath.slice(0, fullPath.lastIndexOf("/"))
    await ensureFolder(folder)
    if (typeof output.data === "string") await app.vault.adapter.write(fullPath, output.data)
    else await app.vault.adapter.writeBinary(fullPath, output.data.buffer.slice(output.data.byteOffset, output.data.byteOffset + output.data.byteLength))
    written.push(fullPath)
  }
  return written
}


async function convertFile(context, file) {
  if (!canConvert(context, file)) return
  const targetId = chosenTarget(context, file)
  const target      = context.engine.getTargets(file.detection).find(candidate => candidate.id === targetId)
  const orientation = target.orientable ? (context.orientations[file.id] ?? "paysage") : null
  const label       = orientation ? target.label.replace(/\)$/, ", " + orientation + ")") : target.label
  context.jobs[file.id] = { targetId, label, progress: 0, stepText: "Conversion…" }
  context.errors[file.id] = null
  render(context)
  try {
    await ensureFolder(OUTPUT_FOLDER)
    const bytes    = new Uint8Array(await app.vault.adapter.readBinary(file.original))
    const baseRaw  = safeName(splitName(file.name).base) + target.suffix
    const baseName = await chooseBaseName(baseRaw, target.extension)
    const outputs  = await context.engine.convert({
      bytes,
      detection:    file.detection,
      targetId,
      baseName,
      pages:        context.pages[file.id] ?? "",
      orientation,
      outputFolder: OUTPUT_FOLDER,
      sourcePath:   file.original,
      onProgress:   (share, text) => { const job = context.jobs[file.id]; if (job) { job.progress = share; job.stepText = text; updateProgress(context, file) } }
    })
    const written  = await writeOutputs(outputs)
    file.conversions.push({ id: newId(), targetId, label, outputs: written, createdAt: new Date().toISOString() })
    await saveHistory(context)
  } catch (error) {
    context.errors[file.id] = { label, message: readableError(error) }
  }
  delete context.jobs[file.id]
  render(context)
}


async function convertAllPending(context) {
  const files = visibleFiles(context).filter(file => file.conversions.length === 0 && canConvert(context, file))
  for (const file of files) await convertFile(context, file)
}


// Assembling or merging: one conversion attached to the first file of the chosen order, naming the others.
async function convertGroup(context, members, engineFunction, outputName, label) {
  if (members.length < 2) return
  const leader  = members[0]
  members.forEach(file => { context.jobs[file.id] = { label, progress: 0, stepText: "Assemblage…" } })
  render(context)
  try {
    await ensureFolder(OUTPUT_FOLDER)
    const items = []
    for (const file of members) items.push({ bytes: new Uint8Array(await app.vault.adapter.readBinary(file.original)), detection: file.detection })
    const baseName = await chooseBaseName(safeName(outputName), "pdf")
    const written  = await writeOutputs(await engineFunction(items, baseName))
    const others   = members.slice(1).map(file => file.name)
    leader.conversions.push({ id: newId(), targetId: "groupe", label, outputs: written, createdAt: new Date().toISOString(), with: others })
    await saveHistory(context)
  } catch (error) {
    context.errors[leader.id] = { label, message: readableError(error) }
  }
  members.forEach(file => { delete context.jobs[file.id] })
  render(context)
}


// ---------- Deleting ----------

// Moves a conversion's results to Obsidian's trash. An output folder ("<name> - pages", "<name> - images") goes whole.
function topLevelOutputs(outputs) {
  const prefix   = OUTPUT_FOLDER + "/"
  const topItems = new Set()
  for (const path of outputs) {
    const relative   = path.startsWith(prefix) ? path.slice(prefix.length) : path
    const isInFolder = relative.includes("/")
    topItems.add(isInFolder ? prefix + relative.split("/")[0] : path)
  }
  return [...topItems]
}


async function trashPath(path) {
  const exists = await app.vault.adapter.exists(path)
  if (!exists) return
  const item = app.vault.getAbstractFileByPath(path)
  if (item) await app.vault.trash(item, false)
  else await app.vault.adapter.trashLocal(path)
}


function describeOutputs(conversion) {
  const tops = topLevelOutputs(conversion.outputs)
  return tops.map(path => {
    const name  = path.split("/").pop()
    const count = conversion.outputs.filter(output => output.startsWith(path + "/")).length
    return count ? name + " (" + count + " fichiers)" : name
  })
}


// ---------- Opening ----------

async function ensureStillThere(context, path) {
  const exists = await app.vault.adapter.exists(path)
  if (exists) return true
  await reconcile(context)
  render(context)
  setStatus(context, "Ce fichier a été supprimé ou déplacé.")
  return false
}


async function openPath(context, path) {
  if (!(await ensureStillThere(context, path))) return
  const extension = path.split(".").pop().toLowerCase()
  if (OPENABLE_IN_OBSIDIAN.includes(extension)) {
    await app.workspace.openLinkText(path, "", "tab")
    return
  }
  if (typeof app.openWithDefaultApp === "function") { app.openWithDefaultApp(path); return }
  const modules = context.modules
  if (modules) modules.electron.shell.openPath(modules.path.join(app.vault.adapter.basePath, path))
}


async function revealPath(context, path) {
  if (!(await ensureStillThere(context, path))) return
  const modules = context.modules
  const exists  = Boolean(app.vault.getAbstractFileByPath(path))
  if (typeof app.showInFolder === "function" && exists) { app.showInFolder(path); return }
  if (modules && app.vault.adapter.basePath) {
    const fullPath = modules.path.join(app.vault.adapter.basePath, path)
    modules.electron.shell.showItemInFolder(fullPath)
    return
  }
  const explorer = app.internalPlugins?.getPluginById?.("file-explorer")?.instance
  const item     = app.vault.getAbstractFileByPath(path)
  if (explorer && item) explorer.revealInFolder(item)
}


async function openFolder(context, folder) {
  await ensureFolder(folder)
  const modules = context.modules
  if (modules && app.vault.adapter.basePath) {
    modules.electron.shell.openPath(modules.path.join(app.vault.adapter.basePath, folder))
    return
  }
  const explorer = app.internalPlugins?.getPluginById?.("file-explorer")?.instance
  const item     = app.vault.getAbstractFileByPath(folder)
  if (explorer && item) explorer.revealInFolder(item)
}


// ---------- Rendering ----------

function normalize(text) {
  return String(text ?? "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase()
}


function categoryOf(file) {
  return KINDS[file.detection.kind]?.category ?? "autres"
}


function visibleFiles(context) {
  const query = normalize(context.search)
  return context.files.filter(file => {
    const inCategory = context.filter === "tous" || categoryOf(file) === context.filter
    if (!inCategory) return false
    if (!query) return true
    const names = [file.name, ...file.conversions.flatMap(conversion => conversion.outputs.map(path => path.split("/").pop()))]
    return names.some(name => normalize(name).includes(query))
  })
}


function dayLabel(date) {
  const today     = new Date()
  const start     = new Date(today.getFullYear(), today.getMonth(), today.getDate())
  const day       = new Date(date.getFullYear(), date.getMonth(), date.getDate())
  const ONE_DAY   = 86400000
  const difference = Math.round((start - day) / ONE_DAY)
  if (difference === 0) return "Aujourd'hui"
  if (difference === 1) return "Hier"
  return date.toLocaleDateString(LOCALE, { day: "numeric", month: "short", year: "numeric" })
}


function timeLabel(iso, withDay) {
  const date = new Date(iso)
  const time = date.getHours() + " h " + String(date.getMinutes()).padStart(2, "0")
  if (!withDay) return time
  const day  = dayLabel(date)
  if (day === "Aujourd'hui") return time
  return (day === "Hier" ? "hier" : day) + ", " + time
}


function summaryOf(context) {
  const fileCount       = context.files.length
  const conversionCount = context.files.reduce((total, file) => total + file.conversions.length, 0)
  if (!fileCount) return "Aucun fichier"
  const files       = fileCount + (fileCount > 1 ? " fichiers" : " fichier")
  const conversions = conversionCount + (conversionCount > 1 ? " conversions" : " conversion")
  return files + " · " + conversions
}


function selectedFiles(context) {
  return context.files.filter(file => context.selection.has(file.id))
}


function selectionState(context, files) {
  const count = files.filter(file => context.selection.has(file.id)).length
  if (count === 0) return false
  return count === files.length ? true : "mixed"
}


function pruneSelection(context) {
  const existing = new Set(context.files.map(file => file.id))
  for (const id of [...context.selection]) if (!existing.has(id)) context.selection.delete(id)
}


function isImage(file) {
  return (file.detection.kind === "image" || file.detection.kind === "svg") && !file.missing
}


function isPdf(file) {
  return file.detection.kind === "pdf" && !file.missing
}

// ---------- Screen state ----------

// Runtime state kept while Obsidian runs (window.cvContexte): filter, search, chosen targets, running jobs, errors,
// selection. The screen re-renders with context.refresh(); a job finishing after the view closed changes nothing on screen.
function setStatus(context, message) {
  context.status = message ?? ""
  context.refresh()
}


function render(context) {
  pruneSelection(context)
  context.refresh()
}


function updateProgress(context) {
  context.refresh()
}


function orderedVisible(context) {
  return visibleFiles(context).sort((first, second) => second.addedAt.localeCompare(first.addedAt)).map(file => file.id)
}


function toggleFile(context, id, event) {
  const select = !context.selection.has(id)
  const order  = orderedVisible(context)
  const anchor = context.lastChosen
  const ranged = event?.shiftKey && anchor && order.includes(anchor)
  const ids    = ranged ? order.slice(Math.min(order.indexOf(anchor), order.indexOf(id)), Math.max(order.indexOf(anchor), order.indexOf(id)) + 1) : [id]
  ids.forEach(item => select ? context.selection.add(item) : context.selection.delete(item))
  context.lastChosen = id
  render(context)
}


function setSelection(context, files, selected) {
  files.forEach(file => selected ? context.selection.add(file.id) : context.selection.delete(file.id))
  render(context)
}


function fileMenu(context, file) {
  const items = []
  if (!file.missing) items.push({ text: "Ouvrir l'original", icon: "file", onClick: () => openPath(context, file.original) })
  if (!file.missing) items.push({ text: "Afficher dans le dossier", icon: "folder", onClick: () => revealPath(context, file.original) })
  if (items.length) items.push("separator")
  items.push({ text: "Supprimer", icon: "trash-2", warning: true, onClick: () => confirmDeleteFile(context, file) })
  return items
}


// ---------- Screen ----------

function Ecran({ app: info }) {
  const { html, useState, useEffect, useReducer, useRef, Entete } = majord.vue
  const [, refresh] = useReducer(value => value + 1, 0)
  const [context]   = useState(() => {
    const kept = window.cvContexte ?? { filter: "tous", search: "", targets: {}, pages: {}, orientations: {}, jobs: {}, errors: {}, selection: new Set(), status: "" }
    window.cvContexte = kept
    kept.orientations = kept.orientations ?? {}
    kept.selection    = kept.selection ?? new Set()
    kept.files        = kept.files ?? []
    kept.info         = info
    kept.modules      = getNodeModules()
    kept.refresh      = () => {}
    return kept
  })
  const picker = useRef(null)
  const zone   = useRef(null)
  useEffect(() => {
    let alive       = true
    context.refresh = () => { if (alive) refresh() }
    const start = async () => {
      context.engine = context.engine ?? await loadEngine()
      if (!Object.keys(context.jobs).length) context.files = await loadHistory()
      const imported = await importInbox(context)
      await reconcile(context)
      if (imported) await saveHistory(context)
      context.ready = true
      render(context)
    }
    start().catch(error => setStatus(context, "Chargement impossible : " + readableError(error)))
    return () => {
      alive           = false
      context.refresh = () => {}
    }
  }, [])
  useVaultWatch(context)
  useEscape(context)
  useDropZone(context, zone)
  const pick = () => picker.current?.click()
  return html`
    <input ref=${picker} type="file" multiple style="display:none" aria-hidden="true" onChange=${async event => { await addFiles(context, event.currentTarget.files); event.currentTarget.value = "" }} />
    <${Entete} nom=${info.name} icone=${info.icon} couleur=${info.color} resume=${context.ready ? summaryOf(context) : "Chargement…"} action=${{ texte: "Ajouter des fichiers", icone: "upload", onClick: pick }} />
    <label ref=${zone} class="cv-depot" tabIndex="0" onClick=${event => { event.preventDefault(); pick() }} onKeyDown=${event => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); pick() } }}>
      <${majord.vue.Icone} nom="upload" /><span>Glisse des fichiers ici : images, photos HEIC, PDF, Word, notes, HTML, CSV, Excel, JSON</span>
    </label>
    <div class="cv-carte">
      ${context.ready ? html`<${Contenu} context=${context} />` : html`<div class="cv-vide"><span class="cv-doux">Chargement de l'historique…</span></div>`}
      <div class="cv-pied">
        <${majord.vue.Texte} as="span" class="cv-statut" aria-live="polite">${context.status}<//>
        <span class="cv-espace"></span>
        <button type="button" class="cv-lien" onClick=${() => openFolder(context, ORIGINALS_FOLDER)}>Dossier Originaux</button>
        <button type="button" class="cv-lien" onClick=${() => openFolder(context, OUTPUT_FOLDER)}>Dossier Convertis</button>
      </div>
    </div>
  `
}


// Keeps the list in step with the vault: deleted or moved files, files dropped into Inbox/.
function useVaultWatch(context) {
  majord.vue.useEffect(() => {
    let timer = null
    const onChange = path => {
      if (!String(path ?? "").startsWith(APP_FOLDER + "/") || path.startsWith(HISTORY_FOLDER) || !context.ready) return
      clearTimeout(timer)
      timer = setTimeout(async () => {
        const imported = await importInbox(context)
        const changed  = await reconcile(context)
        if (imported) await saveHistory(context)
        if (imported || changed) render(context)
      }, WATCH_DELAY)
    }
    const refs = [
      app.vault.on("create", file => onChange(file?.path)),
      app.vault.on("delete", file => onChange(file?.path)),
      app.vault.on("rename", (file, oldPath) => onChange(oldPath))
    ]
    return () => {
      clearTimeout(timer)
      for (const ref of refs) app.vault.offref(ref)
    }
  }, [])
}


// Escape clears the selection (not while a window, a menu or a field has the focus).
function useEscape(context) {
  majord.vue.useEffect(() => {
    const onKey = event => {
      if (event.key !== "Escape" || !context.selection.size) return
      if (document.querySelector(".mj-modale, .mj-deroulant-liste, .menu")) return
      if (document.activeElement?.matches?.("input, textarea")) return
      context.selection.clear()
      render(context)
    }
    document.addEventListener("keydown", onKey)
    return () => document.removeEventListener("keydown", onKey)
  }, [])
}


// Files dragged anywhere over the app are added (the whole root highlights the drop zone).
function useDropZone(context, zone) {
  majord.vue.useEffect(() => {
    const root = zone.current?.closest(".cv-app")
    if (!root) return undefined
    let depth  = 0
    const hasFiles = event => Array.from(event.dataTransfer?.types ?? []).includes("Files")
    const enter = event => {
      if (!hasFiles(event)) return
      event.preventDefault()
      event.stopPropagation()
      depth++
      root.classList.add("cv-glisse")
    }
    const over = event => {
      if (!hasFiles(event)) return
      event.preventDefault()
      event.stopPropagation()
      event.dataTransfer.dropEffect = "copy"
    }
    const leave = event => {
      if (!hasFiles(event)) return
      depth = Math.max(0, depth - 1)
      if (depth === 0) root.classList.remove("cv-glisse")
    }
    const drop = async event => {
      if (!hasFiles(event)) return
      event.preventDefault()
      event.stopPropagation()
      depth = 0
      root.classList.remove("cv-glisse")
      await addFiles(context, event.dataTransfer.files)
    }
    const handlers = [["dragenter", enter], ["dragover", over], ["dragleave", leave], ["drop", drop]]
    for (const [name, handler] of handlers) root.addEventListener(name, handler, true)
    return () => { for (const [name, handler] of handlers) root.removeEventListener(name, handler, true) }
  }, [])
}


function Contenu({ context }) {
  const { html, Etape, Liste, Bloc } = majord.vue
  const files    = visibleFiles(context).sort((first, second) => second.addedAt.localeCompare(first.addedAt))
  const entries  = []
  const days     = new Map()
  for (const file of files) {
    const day = dayLabel(new Date(file.addedAt))
    if (!days.has(day)) days.set(day, [])
    days.get(day).push(file)
  }
  for (const [day, members] of days) {
    entries.push({ key: "jour-" + day, day: day, members: members })
    for (const file of members) entries.push({ key: "fichier-" + file.id, file: file })
  }
  const searching = context.search || context.filter !== "tous"
  const empty     = context.files.length && searching
  return html`
    <${Etape} cle=${context.selection.size ? "selection" : "outils"}>
      ${context.selection.size ? html`<${SelectionBar} context=${context} />` : html`<${Toolbar} context=${context} />`}
    <//>
    <${Bloc} visible=${!files.length} class="cv-vide">
      <b>${empty ? "Aucun fichier ne correspond" : "Aucun fichier pour l'instant"}</b>
      <span class="cv-doux">${empty ? "Change la recherche ou l'onglet." : "Glisse des fichiers dans la zone ci-dessus, ou mets-les dans « " + INBOX_FOLDER + " ». Chaque fichier est conservé et peut être converti autant de fois que tu veux."}</span>
    <//>
    <${Liste} class="cv-liste" items=${entries} cle=${entry => entry.key} rendu=${entry => entry.day ? html`<${DayHeader} context=${context} day=${entry.day} members=${entry.members} />` : html`<${FileGroup} context=${context} file=${entry.file} />`} />
  `
}


function DayHeader({ context, day, members }) {
  const { html, Case } = majord.vue
  return html`<div class="cv-jour"><${Case} etat=${selectionState(context, members)} libelle=${"Sélectionner les fichiers : " + day} onChange=${() => setSelection(context, members, selectionState(context, members) !== true)} /><${majord.vue.Texte} as="span">${day} · ${members.length}<//></div>`
}


// Discreet help after the tabs (ux.md §Help): what each category converts to. Opens on the "i" only, never on a tab.
function conversionsHelp(context) {
  const items = Object.entries(CATEGORY_SOURCES).map(([categoryId, category]) => {
    const label   = FILTERS.find(filter => filter.id === categoryId)?.label ?? categoryId
    const sources = category.sources.map(source => source.label.replace(/ \(.*\)$/, "")).join(", ")
    const targets = [...new Set(category.sources.flatMap(source => context.engine.getTargets(source.detection).map(target => target.label.replace(/…$/, "").replace(/ \(.*\)$/, ""))))]
    return label + " (" + sources + ") : " + targets.join(", ") + (category.groups.length ? ". " + category.groups.join(". ") : "")
  })
  return { title: "Conversions possibles", text: "Chaque fichier ne propose que les formats possibles pour son type.", items: items }
}


function Toolbar({ context }) {
  const { html, Saisie } = majord.vue
  const files   = context.files
  const counts  = Object.fromEntries(FILTERS.map(filter => [filter.id, filter.id === "tous" ? files.length : files.filter(file => categoryOf(file) === filter.id).length]))
  const busy    = Object.keys(context.jobs).length > 0
  const waiting = visibleFiles(context).filter(file => file.conversions.length === 0 && canConvert(context, file)).length
  return html`
    <div class="cv-barre">
      ${FILTERS.map(filter => html`<button type="button" key=${filter.id} class=${"cv-onglet" + (context.filter === filter.id ? " cv-actif" : "")}
        onClick=${() => { context.filter = filter.id; render(context) }}>${filter.label}<span class="cv-compte">${counts[filter.id]}</span></button>`)}
      <${majord.vue.Aide} contenu=${conversionsHelp(context)} />
      <span class="cv-espace"></span>
      <${Saisie} class="cv-recherche" icone="search" placeholder="Rechercher un fichier" libelle="Rechercher un fichier" valeur=${context.search} onInput=${value => { context.search = value; render(context) }} />
      <button type="button" class="cv-bouton cv-petit cv-principal" disabled=${!waiting || busy} onClick=${() => convertAllPending(context)}>Tout convertir${waiting ? " (" + waiting + ")" : ""}</button>
    </div>
  `
}


function SelectionBar({ context }) {
  const { html, Case } = majord.vue
  const visible     = visibleFiles(context)
  const selected    = selectedFiles(context)
  const count       = selected.length
  const busy        = Object.keys(context.jobs).length > 0
  const convertible = selected.filter(file => canConvert(context, file))
  const allVisible  = visible.every(file => context.selection.has(file.id))
  const convertAll  = async () => { for (const file of convertible) await convertFile(context, file) }
  return html`
    <div class="cv-barre cv-selection">
      <${Case} etat=${selectionState(context, visible) || "mixed"} libelle=${allVisible ? "Désélectionner tout" : "Tout sélectionner"} onChange=${() => setSelection(context, visible, !allVisible)} />
      <${majord.vue.Texte} as="span" class="cv-selection-compte">${count} ${count > 1 ? "sélectionnés" : "sélectionné"}<//>
      ${allVisible ? null : html`<button type="button" class="cv-lien" onClick=${() => setSelection(context, visible, true)}>Tout sélectionner (${visible.length})</button>`}
      <button type="button" class="cv-lien" style="color:#c2c9d1" onClick=${() => { context.selection.clear(); render(context) }}>Désélectionner</button>
      <span class="cv-espace"></span>
      ${count >= 2 && selected.every(isImage) ? html`<button type="button" class="cv-bouton cv-petit" disabled=${busy} onClick=${() => openGroupWindow(context, "assembler")}>Assembler en un PDF</button>` : null}
      ${count >= 2 && selected.every(isPdf) ? html`<button type="button" class="cv-bouton cv-petit" disabled=${busy} onClick=${() => openGroupWindow(context, "fusionner")}>Fusionner en un PDF</button>` : null}
      ${convertible.length ? html`<button type="button" class="cv-bouton cv-petit" disabled=${busy} onClick=${convertAll}>Convertir (${convertible.length})</button>` : null}
      <button type="button" class="cv-bouton cv-petit cv-danger-ligne" disabled=${busy} onClick=${() => confirmDeleteSelection(context)}>Supprimer (${count})</button>
    </div>
  `
}


function Tile({ file }) {
  const { html } = majord.vue
  const kind    = KINDS[file.detection.kind] ?? KINDS.inconnu
  if (file.missing) return html`<span class="cv-vignette cv-absente">${kind.tile}</span>`
  if (PREVIEW_FORMATS.includes(file.detection.format)) return html`<span class="cv-vignette" style=${{ backgroundImage: "url('" + app.vault.adapter.getResourcePath(file.original) + "')", backgroundColor: "rgba(255,255,255,.08)" }}></span>`
  return html`<span class="cv-vignette" style=${{ background: kind.background, color: kind.color }}>${kind.tile}</span>`
}


function TargetControls({ context, file }) {
  const { html, Choix, Saisie } = majord.vue
  if (file.missing) return null
  if (file.detection.kind === "inconnu") return html`<span class="cv-etiquette cv-alerte">${file.detection.message ?? "Format non pris en charge"}</span>`
  const busy     = hasJob(context, file)
  const targetId = chosenTarget(context, file)
  const target   = context.engine.getTargets(file.detection).find(candidate => candidate.id === targetId)
  const options  = context.engine.getTargets(file.detection).map(candidate => ({ value: candidate.id, label: candidate.label }))
  const again    = file.conversions.length > 0
  return html`
    <div class="cv-actions">
      <span class="cv-cible"><span class="cv-cible-libelle">Vers</span><${Choix} options=${options} valeur=${targetId} libelle=${"Format de sortie pour " + file.name} onChange=${value => { context.targets[file.id] = value; render(context) }} /></span>
      ${targetId === "extraire" ? html`<${Saisie} class="cv-pages" placeholder="Pages : 1-3, 5" libelle="Pages à extraire" valeur=${context.pages[file.id] ?? ""} onInput=${value => { context.pages[file.id] = value }} />` : null}
      ${target?.orientable ? html`<${Choix} options=${[{ value: "paysage", label: "Paysage" }, { value: "portrait", label: "Portrait" }]} valeur=${context.orientations[file.id] ?? "paysage"} libelle="Orientation des pages" onChange=${value => { context.orientations[file.id] = value }} />` : null}
      <button type="button" class=${"cv-bouton" + (again ? "" : " cv-accent")} disabled=${busy} onClick=${() => convertFile(context, file)}>${again ? "Reconvertir" : "Convertir"}</button>
    </div>
  `
}


// One original and its children: conversions (oldest first), the running job, the last error.
function FileGroup({ context, file }) {
  const { html, Case, Icone, Liste } = majord.vue
  const kind     = KINDS[file.detection.kind] ?? KINDS.inconnu
  const meta     = file.missing ? kind.label + " · plus de nouvelle conversion possible" : [kind.label, file.details, formatSize(file.size), timeLabel(file.addedAt, false)].filter(Boolean).join(" · ")
  const selected = context.selection.has(file.id)
  const children = [...file.conversions].sort((first, second) => first.createdAt.localeCompare(second.createdAt)).map(conversion => ({ key: "conversion-" + conversion.id, conversion: conversion }))
  if (context.jobs[file.id]) children.push({ key: "travail-" + file.id, job: context.jobs[file.id] })
  if (context.errors[file.id]) children.push({ key: "erreur-" + file.id, error: context.errors[file.id] })
  return html`
    <div class=${"cv-groupe" + (selected ? " cv-choisi" : "")}>
      <div class="cv-ligne">
        <${Case} etat=${selected} libelle=${"Sélectionner " + file.name} onChange=${(next, event) => toggleFile(context, file.id, event)} />
        <${Tile} file=${file} />
        <span class="cv-fichier">
          <span class="cv-titre">${file.missing
            ? html`<span class="cv-barre-nom" title=${file.name}>${file.name}</span><span class="cv-etiquette cv-alerte">Original supprimé</span>`
            : html`<a class="cv-nom" title=${"Ouvrir " + file.name} onClick=${() => openPath(context, file.original)}>${file.name}</a>`}</span>
          <span class="cv-meta">${meta}</span>
        </span>
        <${TargetControls} context=${context} file=${file} />
        <button type="button" class="cv-icone" aria-label=${"Plus d'actions pour " + file.name} title="Plus d'actions" onClick=${event => majord.vue.menu(event.currentTarget, fileMenu(context, file))}><${Icone} nom="more-vertical" /></button>
      </div>
      <${Liste} class="cv-enfants" items=${children} cle=${child => child.key} rendu=${child => child.conversion
        ? html`<${ConversionRow} context=${context} file=${file} conversion=${child.conversion} />`
        : child.job ? html`<${JobRow} job=${child.job} />` : html`<${ErrorRow} context=${context} file=${file} error=${child.error} />`} />
    </div>
  `
}


function ConversionRow({ context, file, conversion }) {
  const { html, Icone } = majord.vue
  const tops    = topLevelOutputs(conversion.outputs)
  const first   = conversion.outputs[0]
  const isGroup = tops.length === 1 && tops[0] !== first
  const name    = isGroup ? tops[0].split("/").pop() : first.split("/").pop()
  const extra   = isGroup ? " · " + conversion.outputs.length + " fichiers" : tops.length > 1 ? " · et " + (tops.length - 1) + (tops.length > 2 ? " autres" : " autre") : ""
  const shared  = conversion.with?.length ? " · avec " + conversion.with.length + (conversion.with.length > 1 ? " autres fichiers" : " autre fichier") : ""
  return html`
    <div class="cv-enfant">
      <${Icone} nom="corner-down-right" />
      <span class="cv-sortie"><a class="cv-nom" title=${"Ouvrir " + name} onClick=${() => openPath(context, first)}>${name}</a><span class="cv-faible">${extra + shared}</span></span>
      <span class="cv-etiquette" style="background:rgba(255,255,255,.08);color:#e9edf1">${conversion.label}</span>
      <span class="cv-heure">${timeLabel(conversion.createdAt, true)}</span>
      <button type="button" class="cv-icone cv-petite" aria-label="Afficher dans le dossier" title="Afficher dans le dossier" onClick=${() => revealPath(context, first)}><${Icone} nom="folder" /></button>
      <button type="button" class="cv-icone cv-petite cv-danger" aria-label="Supprimer cette conversion" title="Supprimer cette conversion" onClick=${() => confirmDeleteConversion(context, file, conversion)}><${Icone} nom="trash-2" /></button>
    </div>
  `
}


// Progress updated in place, never wiped (ux.md: values changed by a running action).
function JobRow({ job }) {
  const { html, Icone } = majord.vue
  return html`
    <div class="cv-enfant cv-en-cours">
      <${Icone} nom="corner-down-right" />
      <span class="cv-progression" data-mj-fixe><span>${job.stepText || "Conversion…"}</span><span class=${"cv-jauge" + (job.progress > 0 ? "" : " cv-indefini")}><i style=${{ width: Math.round(job.progress * 100) + "%" }}></i></span></span>
      <span class="cv-etiquette" style="background:rgba(255,255,255,.08);color:#e9edf1">${job.label}</span>
      <span class="cv-heure"></span>
    </div>
  `
}


function ErrorRow({ context, file, error }) {
  const { html, Icone } = majord.vue
  return html`
    <div class="cv-enfant cv-echec" role="alert">
      <${Icone} nom="corner-down-right" />
      <span class="cv-erreur">${error.label} : ${error.message}</span>
      <button type="button" class="cv-icone cv-petite" aria-label="Masquer l'erreur" title="Masquer l'erreur" onClick=${() => { context.errors[file.id] = null; render(context) }}><${Icone} nom="x" /></button>
    </div>
  `
}


// ---------- Windows ----------

function openWindow(context, options) {
  majord.vue.ouvrirFenetre(Object.assign({ classe: "cv-fenetre", accent: context.info.color, largeur: 480 }, options))
}


// Delete confirmation: what goes to the trash, what stays.
function DeleteForm({ sections, action, onConfirm, fermer }) {
  const { html, Bouton } = majord.vue
  return html`
    <div class="mj-section">
      ${sections.filter(group => group.items.length).map(group => html`
        <div class="mj-section-titre" key=${group.title}>${group.title}</div>
        <div class="cv-fenetre-liste" key=${group.title + "-liste"}>${group.items.map((item, index) => html`<div key=${index} class=${item.startsWith(" ") ? "mj-doux" : ""}>${item.trim()}</div>`)}</div>
      `)}
    </div>
    <div class="mj-fenetre-pied">
      <${Bouton} texte="Annuler" onClick=${fermer} />
      <${Bouton} texte=${action} variante="danger" onClick=${async () => { fermer(); await onConfirm() }} />
    </div>
  `
}


function confirmDeleteConversion(context, file, conversion) {
  openWindow(context, {
    titre: "Supprimer la conversion ?", sousTitre: "Le fichier converti part dans la corbeille d'Obsidian. Tu peux le récupérer." + (file.missing ? "" : " L'original reste là et tu peux le reconvertir."),
    contenu: DeleteForm, props: {
      sections: [{ title: "À la corbeille", items: describeOutputs(conversion) }, { title: "Conservé", items: file.missing ? [] : [file.name + " (original)"] }],
      action: "Supprimer la conversion",
      onConfirm: async () => {
        for (const path of topLevelOutputs(conversion.outputs)) await trashPath(path)
        file.conversions = file.conversions.filter(item => item !== conversion)
        await reconcile(context)
        await saveHistory(context)
        setStatus(context, "Conversion mise à la corbeille d'Obsidian.")
      }
    }
  })
}


function confirmDeleteFile(context, file) {
  const count    = file.conversions.length
  const outputs  = file.conversions.flatMap(conversion => describeOutputs(conversion))
  const original = file.missing ? [] : [file.name + " (original)"]
  openWindow(context, {
    titre: count ? "Supprimer " + file.name + " et " + (count > 1 ? "ses " + count + " conversions ?" : "sa conversion ?") : "Supprimer " + file.name + " ?",
    sousTitre: "Tout part dans la corbeille d'Obsidian. Tu peux le récupérer. La ligne quitte la liste.",
    contenu: DeleteForm, props: {
      sections: [{ title: "À la corbeille", items: [...original, ...outputs] }],
      action: count ? "Tout supprimer" : "Supprimer",
      onConfirm: async () => {
        await trashPath(file.original)
        for (const conversion of file.conversions) for (const path of topLevelOutputs(conversion.outputs)) await trashPath(path)
        context.files = context.files.filter(item => item !== file)
        await saveHistory(context)
        setStatus(context, "Mis à la corbeille d'Obsidian.")
      }
    }
  })
}


function confirmDeleteSelection(context) {
  const files       = selectedFiles(context)
  const conversions = files.reduce((total, file) => total + file.conversions.length, 0)
  const items       = files.flatMap(file => [...(file.missing ? [] : [file.name + " (original)"]), ...file.conversions.flatMap(conversion => describeOutputs(conversion).map(name => "   " + name))])
  const fileText    = files.length + (files.length > 1 ? " fichiers" : " fichier")
  const convText    = conversions ? " et " + (conversions > 1 ? "leurs " + conversions + " conversions" : "leur conversion") : ""
  openWindow(context, {
    titre: "Supprimer " + fileText + convText + " ?", sousTitre: "Tout part dans la corbeille d'Obsidian. Tu peux le récupérer. Les lignes quittent la liste.",
    contenu: DeleteForm, props: {
      sections: [{ title: "À la corbeille (" + items.length + (items.length > 1 ? " éléments)" : " élément)"), items: items }],
      action: "Supprimer " + (files.length > 1 ? "les " + fileText : "le fichier"),
      onConfirm: async () => {
        for (const file of files) {
          await trashPath(file.original)
          for (const conversion of file.conversions) for (const path of topLevelOutputs(conversion.outputs)) await trashPath(path)
        }
        const removed = new Set(files.map(file => file.id))
        context.files = context.files.filter(file => !removed.has(file.id))
        context.selection.clear()
        await saveHistory(context)
        setStatus(context, fileText + " mis à la corbeille d'Obsidian.")
      }
    }
  })
}


// Order of the pages, output name, then assemble (images) or merge (PDF).
function openGroupWindow(context, mode) {
  const order   = orderedVisible(context)
  const members = selectedFiles(context).sort((first, second) => order.indexOf(first.id) - order.indexOf(second.id))
  const isMerge = mode === "fusionner"
  const what    = isMerge ? members.length + " PDF" : members.length + " images"
  openWindow(context, {
    titre: (isMerge ? "Fusionner " : "Assembler ") + what + " en un PDF", largeur: 520,
    sousTitre: (isMerge ? "Les pages de chaque PDF, dans cet ordre." : "Une page par image, dans cet ordre.") + " Les originaux restent là.",
    contenu: GroupForm, props: { context: context, members: members, isMerge: isMerge }
  })
}


function GroupForm({ context, members, isMerge, fermer }) {
  const { html, useState, Liste, Bouton, Saisie } = majord.vue
  const [order, setOrder] = useState(members)
  const [name, setName]   = useState(splitName(members[0].name).base + (isMerge ? " - fusion" : " - images"))
  const move = (index, step) => {
    const next = order.slice()
    ;[next[index], next[index + step]] = [next[index + step], next[index]]
    setOrder(next)
  }
  const run = async () => {
    fermer()
    context.selection.clear()
    await convertGroup(context, order, isMerge ? context.engine.mergePdfs : context.engine.assembleImages, name.trim() || "assemblage", isMerge ? "PDF fusionné" : "PDF (images assemblées)")
  }
  return html`
    <div class="mj-section">
      <div class="mj-section-titre">Ordre des pages</div>
      <${Liste} class="cv-ordre" items=${order} cle=${file => file.id} rendu=${file => {
        const index = order.indexOf(file)
        return html`<div class="cv-ordre-ligne">
          <span class="cv-ordre-numero">${index + 1}</span>
          <span class="cv-ordre-nom">${file.name}</span>
          <${Bouton} icone="chevron-up" variante="lien" titre="Monter" aria-label=${"Monter " + file.name} desactive=${index === 0} onClick=${() => move(index, -1)} />
          <${Bouton} icone="chevron-down" variante="lien" titre="Descendre" aria-label=${"Descendre " + file.name} desactive=${index === order.length - 1} onClick=${() => move(index, 1)} />
        </div>`
      }} />
      <div class="mj-section-titre">Nom du PDF</div>
      <${Saisie} valeur=${name} placeholder="Nom du PDF" libelle="Nom du PDF" onInput=${setName} />
    </div>
    <div class="mj-fenetre-pied">
      <${Bouton} texte="Annuler" onClick=${fermer} />
      <${Bouton} texte=${isMerge ? "Fusionner" : "Assembler"} variante="principal" onClick=${run} />
    </div>
  `
}


module.exports = { Ecran: Ecran, style: STYLE }
