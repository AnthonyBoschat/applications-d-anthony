// Convertisseur: tests without screen (Majord/IA/build-app.md §Tests). Run by the engine in Obsidian.
// Covers detection and data conversions (pure logic). Printing to PDF, image assembly and PDF merge need a screen: checked by hand.
// Never writes: conversions return their files ({ relativePath, data }), nothing is saved.

const SCRIPT_FOLDER  = test.dossier + "/Système/Scripts"
const LIBRARY_FOLDER = test.dossier + "/Système/Bibliothèques"
const encode         = text => new TextEncoder().encode(text)
const decode         = data => typeof data === "string" ? data : new TextDecoder("utf-8").decode(data)

// Same loading as vue.js (loadLibrary, loadEngine), read only.
async function loadLibrary(fileName, globalName) {
  const cache = window.cvBibliotheques ?? {}
  window.cvBibliotheques = cache
  if (cache[fileName]) return cache[fileName]
  const code    = await app.vault.adapter.read(LIBRARY_FOLDER + "/" + fileName)
  const lookup  = "\n;return (typeof " + globalName + " !== 'undefined') ? " + globalName + " : globalThis." + globalName
  const library = new Function("module", "exports", "define", "require", code + lookup).call(globalThis, undefined, undefined, undefined, undefined)
  cache[fileName] = library
  return library
}
loadLibrary.folder = LIBRARY_FOLDER

const engine = new Function("app", "loadLibrary", await app.vault.adapter.read(SCRIPT_FOLDER + "/conversions.js"))(app, loadLibrary)

const SHOPPING = "nom;quantité;prix\nPommes;12;2,5\nPoires;7;3\n"
const convertText = (text, name, targetId) => {
  const bytes = encode(text)
  return engine.convert({ bytes, detection: engine.detectKind(bytes, name), targetId, baseName: "essai" })
}


// ---------- Detection ----------

test.cas("Extension en minuscules, absente sans point", () => {
  test.egal(engine.getExtension("Photo.JPG"), "jpg")
  test.egal(engine.getExtension("archive.tar.gz"), "gz")
  test.egal(engine.getExtension("LISEZMOI"), "")
})

test.cas("Image reconnue par sa signature, même mal nommée", async () => {
  const bytes = await test.lireOctets("Fichiers/carre.png")
  test.egal(engine.detectKind(bytes, "carre.png"), { kind: "image", format: "png" })
  test.egal(engine.detectKind(bytes, "carre.jpg"), { kind: "image", format: "png" })
})

test.cas("CSV, JSON, note et HTML reconnus", () => {
  test.egal(engine.detectKind(encode(SHOPPING), "courses.csv").kind, "csv")
  test.egal(engine.detectKind(encode("[{\"a\":1}]"), "donnees.json").kind, "json")
  test.egal(engine.detectKind(encode("# Titre"), "note.md").kind, "note")
  test.egal(engine.detectKind(encode("<!doctype html><html></html>"), "page.htm").kind, "html")
})

test.cas("JSON mal formé : message clair, pas de conversion", () => {
  const detection = engine.detectKind(encode("{ pas du json"), "cassé.json")
  test.egal(detection.kind, "inconnu")
  test.egal(detection.message, "Fichier JSON mal formé.")
  test.egal(engine.getTargets(detection), [])
})

test.cas("Fichier inconnu : non reconnu", () => {
  test.egal(engine.detectKind(new Uint8Array([0, 1, 2, 3]), "bizarre.xyz").kind, "inconnu")
})


// ---------- Targets ----------

test.cas("Une image ne se convertit pas vers son propre format", () => {
  const ids = engine.getTargets({ kind: "image", format: "png" }).map(target => target.id)
  test.vrai(!ids.includes("png"), "PNG proposé pour un PNG")
  test.vrai(ids.includes("jpg") && ids.includes("pdf"), "JPG et PDF attendus")
})

test.cas("Format proposé par défaut", () => {
  test.egal(engine.getDefaultTarget({ kind: "csv", format: "csv" }), "xlsx")
  test.egal(engine.getDefaultTarget({ kind: "json", format: "json" }), "xlsx")
})


// ---------- Data conversions ----------

test.cas("CSV vers JSON : nombres français typés, séparateur point-virgule", async () => {
  const outputs = await convertText(SHOPPING, "courses.csv", "json")
  test.egal(outputs.length, 1)
  test.egal(outputs[0].relativePath, "essai.json")
  test.egal(JSON.parse(decode(outputs[0].data)), [{ nom: "Pommes", "quantité": 12, prix: 2.5 }, { nom: "Poires", "quantité": 7, prix: 3 }])
})

test.cas("Code à zéro initial gardé en texte", async () => {
  const outputs = await convertText("code;ville\n01234;Lyon\n", "codes.csv", "json")
  test.egal(JSON.parse(decode(outputs[0].data)), [{ code: "01234", ville: "Lyon" }])
})

test.cas("Guillemets et séparateur dans une cellule", async () => {
  const outputs = await convertText("nom,note\n\"Dupont, Jean\",\"il a dit \"\"oui\"\"\"\n", "notes.csv", "json")
  test.egal(JSON.parse(decode(outputs[0].data)), [{ nom: "Dupont, Jean", note: "il a dit \"oui\"" }])
})

test.cas("CSV vers Excel puis Excel vers JSON : mêmes données", async () => {
  const excel   = await convertText(SHOPPING, "courses.csv", "xlsx")
  test.egal(excel[0].relativePath, "essai.xlsx")
  const bytes   = new Uint8Array(excel[0].data)
  const back    = await engine.convert({ bytes, detection: engine.detectKind(bytes, "essai.xlsx"), targetId: "json", baseName: "retour" })
  test.egal(JSON.parse(decode(back[0].data)), [{ nom: "Pommes", "quantité": 12, prix: 2.5 }, { nom: "Poires", "quantité": 7, prix: 3 }])
})

test.cas("JSON vers CSV : en-tête, point-virgule, BOM pour Excel", async () => {
  const outputs = await convertText("[{\"titre\":\"Lecture\",\"pages\":320},{\"titre\":\"Vélo\",\"pages\":0}]", "donnees.json", "csv")
  const text    = decode(outputs[0].data)
  test.vrai(text.startsWith("﻿"), "BOM absent")
  const lines   = text.replace(/^﻿/, "").trim().split(/\r?\n/)
  test.egal(lines[0], "titre;pages")
  test.egal(lines.length, 3)
})

test.cas("Description d'un CSV : nombre de lignes", async () => {
  const bytes = encode(SHOPPING)
  test.egal(await engine.describe(bytes, engine.detectKind(bytes, "courses.csv")), "3 lignes")
})

test.cas("Format de sortie inconnu refusé", async () => {
  await test.erreur(() => convertText(SHOPPING, "courses.csv", "mp3"), "Format de sortie inconnu")
})
