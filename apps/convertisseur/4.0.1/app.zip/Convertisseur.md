---
cssclasses:
  - cv
---
Convertisseur s'ouvre dans sa propre vue Majord. Si tu lis ce texte, active le plugin Majord 0.12 ou plus récent dans Paramètres › Modules complémentaires.
